# Prediction of Multi-Vendor Trucking Performance Using Machine Learning

Undergraduate thesis project.

## Algorithms
- Random Forest
- Naive Bayes

## Features
- Data preprocessing
- SMOTE
- Model evaluation
- Dashboard
